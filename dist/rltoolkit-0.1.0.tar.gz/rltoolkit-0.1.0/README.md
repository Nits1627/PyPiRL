# RLToolkit

A simple and comprehensive reinforcement learning library for Python.

## Features

- **Easy-to-use algorithms**: Q-Learning, SARSA, and Deep Q-Network (DQN)
- **Built-in environments**: GridWorld and Maze environments for testing
- **Flexible policies**: Epsilon-greedy, greedy, and random policies
- **Visualization tools**: Learning curve plotting and evaluation utilities
- **Extensible**: Easy to add new algorithms and environments

## Installation

```bash
pip install rltoolkit
```

## Quick Start

```python
from rltoolkit import QLearning, SimpleGridWorld, EpsilonGreedyPolicy
from rltoolkit.utils import plot_learning_curve

# Create environment and agent
env = SimpleGridWorld(size=5)
agent = QLearning(state_space=env.state_space, action_space=env.action_space)
policy = EpsilonGreedyPolicy(epsilon=0.1)

# Train the agent
rewards = []
for episode in range(1000):
    state = env.reset()
    total_reward = 0
    done = False
    
    while not done:
        action = policy.select_action(agent, state)
        next_state, reward, done = env.step(action)
        agent.update(state, action, reward, next_state)
        state = next_state
        total_reward += reward
    
    rewards.append(total_reward)

# Plot learning curve
plot_learning_curve(rewards)
```

## Available Algorithms

- **Q-Learning**: Model-free off-policy algorithm
- **SARSA**: Model-free on-policy algorithm  
- **DQN**: Deep Q-Network for continuous state spaces

## Available Environments

- **SimpleGridWorld**: Classic grid world environment
- **SimpleMaze**: Maze navigation environment

## Documentation

For detailed documentation and examples, visit: https://rltoolkit.readthedocs.io/

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.